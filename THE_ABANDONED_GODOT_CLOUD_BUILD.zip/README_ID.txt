THE ABANDONED — CLOUD ANDROID BUILD

PENTING:
- Ini project Godot 4.4.1, bukan project Unity.
- ZIP ini bukan APK. APK dihasilkan oleh workflow cloud setelah kamu upload ke repository GitHub dan menjalankan Actions.
- Kamu perlu akun GitHub sendiri untuk memulai build. Jangan pernah membagikan password atau token akun ke chat.
- Prototype memakai geometri sederhana dan monster bayangan placeholder; belum memiliki model/animasi/audio final.

LANGKAH:
1. Buat akun GitHub jika belum punya.
2. Buat repository baru bernama THE-ABANDONED dan pilih Private.
3. Upload semua isi ZIP ini ke root repository (termasuk folder .github).
4. Buka tab Actions pada repository dan izinkan Actions bila diminta.
5. Pilih workflow "Build Android APK" lalu tekan Run workflow.
6. Tunggu proses selesai. Buka hasil run, bagian Artifacts, lalu unduh THE_ABANDONED_APK.
7. Ekstrak artifact ZIP dan instal APK pada HP Android. Android mungkin meminta izin instal aplikasi dari sumber tersebut.

Workflow menggunakan Godot 4.4.1 dan Android SDK pada runner cloud GitHub.
Jika workflow gagal, buka log merah dan kirim screenshot error (jangan kirim password/token).
