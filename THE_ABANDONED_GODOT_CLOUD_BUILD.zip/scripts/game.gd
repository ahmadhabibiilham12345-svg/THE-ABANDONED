extends Node

var keys := 0
var ended := false
var flashlight_on := true
var battery := 100.0
var stamina := 100.0
var player: CharacterBody3D
var monster: CharacterBody3D
var hud: Label
var status: Label
var key_nodes: Array[Node3D] = []
var exit_area: Area3D

func _ready() -> void:
    _build_world()
    _build_player()
    _build_keys()
    _build_monster()
    _build_ui()
    _update_hud()

func _process(delta: float) -> void:
    if ended:
        return
    if flashlight_on:
        battery = maxf(0.0, battery - delta * 2.2)
        if battery <= 0.0:
            flashlight_on = false
    _update_hud()

func _physics_process(delta: float) -> void:
    if ended or player == null:
        return
    _move_player(delta)
    _move_monster(delta)

func _move_player(delta: float) -> void:
    var move_input: Vector2 = get_meta("move", Vector2.ZERO)
    var local_dir := Vector3(move_input.x, 0, move_input.y)
    var direction := (player.transform.basis * local_dir).normalized()
    var running := bool(get_meta("running", false)) and stamina > 0.0 and direction.length() > 0.1
    var speed := 5.0 if running else 3.1
    if running:
        stamina = maxf(0.0, stamina - delta * 24.0)
    else:
        stamina = minf(100.0, stamina + delta * 15.0)
    player.velocity.x = direction.x * speed
    player.velocity.z = direction.z * speed
    if not player.is_on_floor():
        player.velocity.y -= 22.0 * delta
    else:
        player.velocity.y = -0.5
    player.move_and_slide()

func _build_world() -> void:
    var world := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.008, 0.008, 0.016)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.18, 0.19, 0.24)
    env.ambient_light_energy = 0.35
    env.fog_enabled = true
    env.fog_light_color = Color(0.025, 0.025, 0.04)
    env.fog_density = 0.025
    world.environment = env
    add_child(world)

    _box("Floor", Vector3(0,-0.2,0), Vector3(22,0.4,22), Color(0.12,0.12,0.13))
    _box("NorthWall", Vector3(0,1.5,-11), Vector3(22,3,0.35), Color(0.16,0.15,0.15))
    _box("SouthWall", Vector3(0,1.5,11), Vector3(22,3,0.35), Color(0.16,0.15,0.15))
    _box("WestWall", Vector3(-11,1.5,0), Vector3(0.35,3,22), Color(0.16,0.15,0.15))
    _box("EastWall", Vector3(11,1.5,0), Vector3(0.35,3,22), Color(0.16,0.15,0.15))
    # Room partitions with openings
    _box("PartitionL1", Vector3(-4,1.5,-7), Vector3(0.3,3,8), Color(0.18,0.16,0.16))
    _box("PartitionL2", Vector3(-4,1.5,4), Vector3(0.3,3,7), Color(0.18,0.16,0.16))
    _box("PartitionR1", Vector3(4,1.5,-7), Vector3(0.3,3,8), Color(0.18,0.16,0.16))
    _box("PartitionR2", Vector3(4,1.5,4), Vector3(0.3,3,7), Color(0.18,0.16,0.16))
    _box("CrossWallL", Vector3(-7.5,1.5,0), Vector3(7,3,0.3), Color(0.18,0.16,0.16))
    _box("CrossWallR", Vector3(7.5,1.5,0), Vector3(7,3,0.3), Color(0.18,0.16,0.16))
    _box("ExitDoor", Vector3(0,1.5,-10.7), Vector3(2.3,3,0.3), Color(0.25,0.12,0.07))
    var light := OmniLight3D.new()
    light.position = Vector3(0,2.5,0)
    light.light_color = Color(0.65,0.7,1)
    light.light_energy = 0.45
    light.omni_range = 9
    add_child(light)

func _box(n: String, pos: Vector3, size: Vector3, color: Color) -> StaticBody3D:
    var body := StaticBody3D.new()
    body.name = n
    body.position = pos
    var mesh := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    mesh.mesh = box
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 1.0
    mesh.material_override = mat
    body.add_child(mesh)
    var shape := CollisionShape3D.new()
    var box_shape := BoxShape3D.new()
    box_shape.size = size
    shape.shape = box_shape
    body.add_child(shape)
    add_child(body)
    return body

func _build_player() -> void:
    player = CharacterBody3D.new()
    player.name = "Player"
    player.position = Vector3(0,0.95,8)
    add_child(player)
    var collision := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.height = 1.8
    capsule.radius = 0.32
    collision.shape = capsule
    player.add_child(collision)

    var pivot := Node3D.new()
    pivot.position.y = 0.62
    player.add_child(pivot)
    var cam := Camera3D.new()
    cam.current = true
    cam.fov = 78
    pivot.add_child(cam)

    var lamp := SpotLight3D.new()
    lamp.light_energy = 4
    lamp.spot_range = 18
    lamp.spot_angle = 32
    lamp.position = Vector3(0,0,-0.1)
    cam.add_child(lamp)
    set_meta("camera_pivot", pivot)
    set_meta("flashlight", lamp)

func _build_keys() -> void:
    var positions := [Vector3(-7,0.6,-7), Vector3(7,0.6,-7), Vector3(0,0.6,5)]
    for i in positions.size():
        var area := Area3D.new()
        area.position = positions[i]
        var mesh := MeshInstance3D.new()
        var sphere := SphereMesh.new()
        sphere.radius = 0.22
        sphere.height = 0.44
        mesh.mesh = sphere
        var mat := StandardMaterial3D.new()
        mat.albedo_color = Color(1,0.65,0.08)
        mat.emission_enabled = true
        mat.emission = Color(0.5,0.22,0.02)
        mesh.material_override = mat
        area.add_child(mesh)
        var cs := CollisionShape3D.new()
        var shape := SphereShape3D.new()
        shape.radius = 0.8
        cs.shape = shape
        area.add_child(cs)
        area.body_entered.connect(_on_key_body_entered.bind(area))
        add_child(area)
        key_nodes.append(area)

func _on_key_body_entered(body: Node3D, area: Area3D) -> void:
    if body == player and not ended and area in key_nodes:
        key_nodes.erase(area)
        area.queue_free()
        keys += 1
        _say("Kunci ditemukan: %d/3" % keys)

func _build_monster() -> void:
    monster = CharacterBody3D.new()
    monster.name = "Shadow"
    monster.position = Vector3(0,0.95,-6)
    add_child(monster)
    var shape := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.height = 2.1
    capsule.radius = 0.48
    shape.shape = capsule
    monster.add_child(shape)
    var visual := MeshInstance3D.new()
    var mesh := CapsuleMesh.new()
    mesh.height = 2.1
    mesh.radius = 0.48
    visual.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.025,0.012,0.02)
    mat.roughness = 1
    visual.material_override = mat
    monster.add_child(visual)

func _move_monster(delta: float) -> void:
    var dist := monster.global_position.distance_to(player.global_position)
    if dist < 13.0:
        var direction := player.global_position - monster.global_position
        direction.y = 0
        if direction.length() > 0.1:
            monster.velocity = direction.normalized() * 2.65
            monster.move_and_slide()
            monster.look_at(Vector3(player.global_position.x, monster.global_position.y, player.global_position.z))
    else:
        monster.velocity = Vector3.ZERO
    if dist < 1.25:
        _finish(false)

func _build_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    layer.add_child(root)

    hud = Label.new()
    hud.position = Vector2(24,20)
    hud.add_theme_font_size_override("font_size", 24)
    hud.add_theme_color_override("font_color", Color.WHITE)
    root.add_child(hud)

    status = Label.new()
    status.anchor_left = 0.5
    status.anchor_right = 0.5
    status.anchor_top = 0.82
    status.anchor_bottom = 0.9
    status.offset_left = -280
    status.offset_right = 280
    status.add_theme_font_size_override("font_size", 22)
    status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    status.add_theme_color_override("font_color", Color.WHITE)
    root.add_child(status)

    var interact_btn := _button(root, "INTERAKSI", Vector2(0.82,0.82), Vector2(170,72))
    interact_btn.pressed.connect(_try_exit)
    var light_btn := _button(root, "SENTER", Vector2(0.82,0.68), Vector2(140,64))
    light_btn.pressed.connect(_toggle_flashlight)
    var run_btn := _button(root, "LARI", Vector2(0.16,0.82), Vector2(130,64))
    run_btn.button_down.connect(func(): set_meta("running", true))
    run_btn.button_up.connect(func(): set_meta("running", false))

    var joy := TouchScreenButton.new()
    joy.position = Vector2(125, get_viewport().get_visible_rect().size.y - 150)
    joy.action = "ui_up"
    # Simple on-screen direction pad buttons are provided below.
    for data in [["◀",Vector2(50,0),Vector2(-1,0)],["▶",Vector2(200,0),Vector2(1,0)],["▲",Vector2(125,-65),Vector2(0,-1)],["▼",Vector2(125,65),Vector2(0,1)]]:
        var b := _button(root, data[0], Vector2(0.12,0.83) + Vector2(data[1]) / Vector2(1280,720), Vector2(62,58))
        b.button_down.connect(_set_move.bind(data[2]))
        b.button_up.connect(_clear_move)
    set_meta("move", Vector2.ZERO)

func _button(parent: Control, text: String, anchor: Vector2, size: Vector2) -> Button:
    var b := Button.new()
    b.text = text
    b.anchor_left = anchor.x
    b.anchor_right = anchor.x
    b.anchor_top = anchor.y
    b.anchor_bottom = anchor.y
    b.offset_left = -size.x/2
    b.offset_right = size.x/2
    b.offset_top = -size.y/2
    b.offset_bottom = size.y/2
    b.add_theme_font_size_override("font_size", 19)
    parent.add_child(b)
    return b

func _set_move(v: Vector2) -> void:
    set_meta("move", v)
func _clear_move() -> void:
    set_meta("move", Vector2.ZERO)

func _unhandled_input(event: InputEvent) -> void:
    if ended: return
    if event is InputEventScreenDrag:
        var pivot: Node3D = get_meta("camera_pivot")
        player.rotate_y(-event.relative.x * 0.003)
        pivot.rotate_x(-event.relative.y * 0.003)
        pivot.rotation.x = clampf(pivot.rotation.x, -1.2, 1.2)
    elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
        var pivot2: Node3D = get_meta("camera_pivot")
        player.rotate_y(-event.relative.x * 0.003)
        pivot2.rotate_x(-event.relative.y * 0.003)
        pivot2.rotation.x = clampf(pivot2.rotation.x, -1.2, 1.2)
    elif event.is_action_pressed("flashlight"):
        _toggle_flashlight()
    elif event.is_action_pressed("interact"):
        _try_exit()

func _toggle_flashlight() -> void:
    if battery <= 0: return
    flashlight_on = not flashlight_on
    var lamp: SpotLight3D = get_meta("flashlight")
    lamp.visible = flashlight_on

func _try_exit() -> void:
    if player.global_position.z < -9.0 and absf(player.global_position.x) < 1.8:
        if keys >= 3:
            _finish(true)
        else:
            _say("Pintu terkunci. Cari semua 3 kunci!")

func _finish(won: bool) -> void:
    ended = true
    if won:
        _say("KAMU BERHASIL KELUAR!  •  Tekan tombol Mulai Lagi")
    else:
        _say("TERTANGKAP BAYANGAN  •  Tekan tombol Mulai Lagi")
    var root := get_child(get_child_count()-1)
    var restart := _button(root, "MULAI LAGI", Vector2(0.5,0.55), Vector2(260,90))
    restart.pressed.connect(func(): get_tree().reload_current_scene())

func _say(message: String) -> void:
    if status: status.text = message

func _update_hud() -> void:
    if hud:
        hud.text = "KUNCI %d/3     BATERAI %d%%     STAMINA %d%%" % [keys, int(battery), int(stamina)]
